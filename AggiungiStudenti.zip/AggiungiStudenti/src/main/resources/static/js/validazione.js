$(document).ready(function(){
	$('#isform').bootstrapValidator({
		feedbackIcons: {
			valid : 'glyphicon glyphicon-ok',
			invalid : 'glyphicon glyphicon-remove',
			validating : 'glyphicon glyphicon-refresh'
		},
		fields: {
			nome : {
				container : '#name',
				validators : {
					notEmpty : {
						message : 'Il campo nome non pu&ograve; essere vuoto'
					},
					regexp : {
						regexp : /^[a-zA-Z ,.'-]{2,30}$/,
						message : 'Da 2 a 30 caratteri (Solo lettere accettate)'
					}
				}
			},
			numero : {
				container : '#phoneNo',
				validators : {
					notEmpty : {
						message : 'Il campo cap non pu&ograve; essere vuoto'
					},
					regexp : {
						regexp : /^[0-9]{10}$/,
						message : 'Inserire 10 cifre per il cap'
					}
				}
			},
			mail : {
				container : '#email',
				validators : {
					notEmpty : {
						message : 'Il campo mail non pu&ograve; essere vuoto'
					},
					regexp : {
						regexp : /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}$/,
						message : 'Inserire una mail valida'
					}
				}
			}
		}
	});
});

		