package Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import dao.CalciatoriDAO;
import model.Calciatori;

@Controller
public class CalciatoriController {
	@Autowired
	CalciatoriDAO dao;

	@RequestMapping("/calcform")
	public ModelAndView visualizzaForm() {
		return new ModelAndView("paginaform", "command", new Calciatori());
	}

	@RequestMapping(value = "/salva", method = RequestMethod.POST)
	public ModelAndView scriviCalciatore(@ModelAttribute("calciatore") Calciatori c) {
		dao.create(c);
		return new ModelAndView("redirect:/calcreport");
	}

	@RequestMapping("/calcreport")
	public ModelAndView visualizzaCalciatore() {
		List<Calciatori> lista = dao.getCalciatori();
		return new ModelAndView("paginareport", "list", lista);
	}
	
	@RequestMapping("/modificatemp/{id}")
	public ModelAndView modificaTemp(@PathVariable long id) {
		Calciatori c = dao.getById(id);
		return new ModelAndView("paginamodifica", "command", c);
	}
	
	@RequestMapping(value="/modifica", method=RequestMethod.POST) //metodo di invio dei dati
	public ModelAndView modificaCalciatore(@ModelAttribute("calc") Calciatori c) {
		dao.update(c);
		return new ModelAndView("redirect:/calcreport"); //cosi faccio la modifica e reindirizzo il sito nel report dei calciatori senza restituirmi il dato
	}
	
	@RequestMapping(value="/cancella/{id}", method=RequestMethod.GET) 
	public ModelAndView cancella(@PathVariable long id) {
		dao.delete(id);
		return new ModelAndView("redirect:/calcreport");
	}
}
