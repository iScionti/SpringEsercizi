package Controller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import dao.CalciatoriDAO;

import org.springframework.beans.factory.annotation.Autowired;
@Controller
public class IndexController {
@Autowired
CalciatoriDAO dao;

@RequestMapping("/")
public ModelAndView visualizzaForm() {
	return new ModelAndView("index", "command", new CalciatoriController());
}
}
