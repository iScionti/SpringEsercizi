package dao;

public interface DaoConstants {
	String CALCSEQ_NEXTVAL ="select calc_seq.nextval from dual";
	String  INSERT_CALCIATORE ="insert into calciatori values(?,?,?,?,?)";
	String UPDATE_CALCIATORE = "update calciatori set nome=?, cognome=?, stipendio=?, ruolo=? where id=?";
	String DELETE_CALCIATORE = "delete from calciatori where id=?";
	String SELECT_CALCIATORE = "select * from calciatori";
	String SELECT_CAL_BY_ID = "select * from calciatori where id = ?";
}
