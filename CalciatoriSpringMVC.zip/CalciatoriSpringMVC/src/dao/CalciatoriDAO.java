package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;


import model.Calciatori;

public class CalciatoriDAO implements DaoConstants {
	@Autowired
	DataSource datasource;
	
	@Autowired
	JdbcTemplate jdbcTemplate; // semplifica la lettura e la scrittura dei dati nel DB

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int create(Calciatori c) {
		SqlRowSet rs = jdbcTemplate.queryForRowSet(CALCSEQ_NEXTVAL);
		rs.next();
		long id = rs.getLong(1);
		return jdbcTemplate.update(INSERT_CALCIATORE,
				new Object[] { id, c.getNome(), c.getCognome(), c.getStipendio(), c.getRuolo() });
	}

	public int update(Calciatori c) {
		return jdbcTemplate.update(UPDATE_CALCIATORE,
				new Object[] { c.getNome(), c.getCognome(), c.getStipendio(), c.getRuolo(), c.getId() });
	}
	
	public int delete(long id) {
		return jdbcTemplate.update(DELETE_CALCIATORE, new Object[] { id });
	}
	
	public Calciatori getById(long id) {
		return jdbcTemplate.queryForObject(SELECT_CAL_BY_ID, new Object[] { id },
				new BeanPropertyRowMapper<Calciatori>(Calciatori.class)); // mi deve tornare un oggetto da questa
																		// operazione
	}
	
	public List<Calciatori> getCalciatori() {
		return jdbcTemplate.query(SELECT_CALCIATORE, new RowMapper<Calciatori>() {

			@Override
			public Calciatori mapRow(ResultSet rs, int rigaCorrente) throws SQLException {
				Calciatori c = new Calciatori();
				c.setId(rs.getLong(1));
				c.setNome(rs.getString(2));
				c.setCognome(rs.getString(3));
				c.setStipendio(rs.getDouble(4));
				c.setRuolo(rs.getString(5));
				return c;
			}
		});
	}
}
