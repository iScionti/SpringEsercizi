package model;

public class Calciatori {
	private Long id;
	private String nome;
	private String cognome;
	private double stipendio;
	private String ruolo;

	public Calciatori() {
	}
	
	public Calciatori(Long id, String nome, String cognome, double stipendio, String ruolo) {
		this.id = id;
		this.nome = nome;
		this.cognome = cognome;
		this.stipendio = stipendio;
		this.ruolo = ruolo;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public double getStipendio() {
		return stipendio;
	}

	public void setStipendio(double stipendio) {
		this.stipendio = stipendio;
	}

	public String getRuolo() {
		return ruolo;
	}

	public void setRuolo(String ruolo) {
		this.ruolo = ruolo;
	}

	@Override
	public String toString() {
		return "Calciatori [id=" + id + ", nome=" + nome + ", cognome=" + cognome + ", stipendio=" + stipendio
				+ ", ruolo=" + ruolo + "]";
	}
	
	
	
}
